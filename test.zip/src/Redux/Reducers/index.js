import { combineReducers} from "redux";
import cartItems from './cartReducer';
const combineReducer = combineReducers({
    cartItems 
  });
  export default combineReducer